/* ==========================================================
   BAGIAN 1 — PENGATURAN TOKO (file: js/config.js)
   Ubah nomor WhatsApp, kontak, kota asal ongkir, voucher, dll di sini.
   ========================================================== */

const WA='628979237494';   // Nomor WhatsApp admin: awali 62, tanpa 0 di depan (0897... -> 62897...)
const MSG='Assalamualaikum Warahmatullahi Wabarakatuh, Saya ingin membeli kitab';  // Pesan otomatis tombol WhatsApp

/* Kontak footer — GANTI dengan akun asli toko */
const CT={
  mail:'mailto:info@huseinstore.com',                                   // Email
  ig:'https://instagram.com/huseinstore',                               // Instagram
  tg:'https://t.me/+628979237494',                                      // Telegram
  map:'https://www.google.com/maps/search/?api=1&query=Husein+Store'    // Lokasi toko offline (tempel link Google Maps toko Anda)
};

const VOUCHER={kode:'KITAB10',persen:10}; // Kode voucher & besar diskon (%)
const PER_SLIDE=5;                        // Jumlah buku per slide

/* Metode pembayaran pilihan pembeli (dikonfirmasi lewat WhatsApp). Tulis 'COD' persis untuk bayar di tempat */
const PY=['BCA Virtual Account','Mandiri Virtual Account','QRIS','DANA / GoPay / ShopeePay','COD'];
