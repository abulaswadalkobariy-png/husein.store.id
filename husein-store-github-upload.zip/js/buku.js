/* ==========================================================
   BAGIAN 3 — DAFTAR KITAB & EBOOK (file: js/buku.js)
   Tambah/kurangi buku di sini. Satu baris { ... } = satu buku. Lihat PANDUAN.md.
   ========================================================== */

/* Penjelasan isi tiap baris:
   id        kode unik, tidak boleh sama dengan buku lain (mis. 'a9')
   jenis     'ebook'  |  'terjemahan'  |  'arab'
   kategori  salah satu dari daftar CATS di bawah
   arab      judul Arab (tampil di sampul)       nama    nama dalam bahasa Indonesia
   harga     harga normal (angka, tanpa titik)   diskon  persen diskon (0 = tanpa diskon)
   judul     (hanya ebook) jumlah judul dalam paket
   gambar    foto sampul, mis. 'gambar/fathul-qarib.jpg' — kosongkan '' untuk sampul otomatis
   aktif     tulis aktif:false untuk menyembunyikan buku sementara (tanpa menghapus)            */
const BUKU=[
  /* ----- EBOOK ----- */
  {id:'e1', jenis:'ebook', kategori:'akidah', arab:'مجموعة كتب العقيدة', nama:'Kumpulan Ebook Akidah', harga:49000, diskon:0, judul:70, gambar:''},
  {id:'e2', jenis:'ebook', kategori:'fikih', arab:'مجموعة كتب الفقه', nama:'Kumpulan Ebook Fikih', harga:59000, diskon:15, judul:120, gambar:''},
  {id:'e3', jenis:'ebook', kategori:'hadits', arab:'مجموعة كتب الحديث', nama:'Kumpulan Ebook Hadist & Syarah', harga:49000, diskon:0, judul:80, gambar:''},
  {id:'e4', jenis:'ebook', kategori:'tafsir', arab:'مجموعة كتب التفسير', nama:'Kumpulan Ebook Tafsir', harga:69000, diskon:20, judul:60, gambar:''},
  {id:'e5', jenis:'ebook', kategori:'bahasa', arab:'مجموعة كتب النحو والصرف', nama:'Kumpulan Ebook Bahasa Arab', harga:45000, diskon:0, judul:40, gambar:''},
  {id:'e6', jenis:'ebook', kategori:'sirah', arab:'مجموعة كتب السيرة', nama:'Kumpulan Ebook Sirah', harga:39000, diskon:10, judul:50, gambar:''},
  /* ----- KITAB TERJEMAHAN ----- */
  {id:'t1', jenis:'terjemahan', kategori:'akidah', arab:'عقيدة العوام', nama:'Aqidatul Awam (Terjemah)', harga:35000, diskon:0, gambar:''},
  {id:'t2', jenis:'terjemahan', kategori:'fikih', arab:'فتح القريب', nama:'Fathul Qarib (Terjemah)', harga:95000, diskon:10, gambar:''},
  {id:'t3', jenis:'terjemahan', kategori:'fikih', arab:'سفينة النجاة', nama:'Safinatun Najah (Terjemah)', harga:40000, diskon:0, gambar:''},
  {id:'t4', jenis:'terjemahan', kategori:'hadits', arab:'رياض الصالحين', nama:'Riyadhus Shalihin (Terjemah)', harga:135000, diskon:15, gambar:''},
  {id:'t5', jenis:'terjemahan', kategori:'hadits', arab:'بلوغ المرام', nama:'Bulughul Maram (Terjemah)', harga:105000, diskon:0, gambar:''},
  {id:'t6', jenis:'terjemahan', kategori:'tafsir', arab:'تفسير الجلالين', nama:'Tafsir Jalalain (Terjemah)', harga:185000, diskon:0, gambar:''},
  {id:'t7', jenis:'terjemahan', kategori:'bahasa', arab:'الأجرومية', nama:'Jurumiyyah (Terjemah)', harga:30000, diskon:0, gambar:''},
  {id:'t8', jenis:'terjemahan', kategori:'sirah', arab:'الرحيق المختوم', nama:'Ar-Rahiq Al-Makhtum (Terjemah)', harga:125000, diskon:10, gambar:''},
  /* ----- KITAB ARAB ----- */
  {id:'a1', jenis:'arab', kategori:'akidah', arab:'العقيدة الطحاوية', nama:'Al-‘Aqidah Ath-Thahawiyyah', harga:55000, diskon:0, gambar:''},
  {id:'a2', jenis:'arab', kategori:'akidah', arab:'كتاب التوحيد', nama:'Kitab At-Tauhid', harga:40000, diskon:10, gambar:''},
  {id:'a3', jenis:'arab', kategori:'fikih', arab:'فتح القريب المجيب', nama:'Fathul Qarib Al-Mujib', harga:75000, diskon:0, gambar:''},
  {id:'a4', jenis:'arab', kategori:'hadits', arab:'رياض الصالحين', nama:'Riyadhus Shalihin', harga:120000, diskon:0, gambar:''},
  {id:'a5', jenis:'arab', kategori:'hadits', arab:'بلوغ المرام', nama:'Bulughul Maram', harga:90000, diskon:15, gambar:''},
  {id:'a6', jenis:'arab', kategori:'tafsir', arab:'تفسير الجلالين', nama:'Tafsir Jalalain', harga:150000, diskon:0, gambar:''},
  {id:'a7', jenis:'arab', kategori:'bahasa', arab:'ألفية ابن مالك', nama:'Alfiyah Ibnu Malik', harga:75000, diskon:0, gambar:''},
  {id:'a8', jenis:'arab', kategori:'sirah', arab:'الرحيق المختوم', nama:'Ar-Rahiq Al-Makhtum', harga:110000, diskon:0, gambar:''},
];
const CATS=['akidah','fikih','hadits','tafsir','bahasa','sirah'];  // KATEGORI. Jika menambah, tambahkan juga tulisannya di bahasa.js (c_namakategori)
