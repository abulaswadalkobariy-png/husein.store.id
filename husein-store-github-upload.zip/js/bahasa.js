/* ==========================================================
   BAGIAN 2 — TEKS & BAHASA (file: js/bahasa.js)
   Semua tulisan di website. Pola: nama:['Indonesia','Arab']. Ubah tulisan di antara tanda petik saja.
   ========================================================== */
const D={
brand:['Husein Store','متجر حسين'],n_home:['Beranda','الرئيسية'],n_cat:['Katalog','الكتالوج'],n_disc:['Diskon','التخفيضات'],n_kat:['Kategori','الأقسام'],
h1:['Kitab & ebook pilihan para penuntut ilmu','كتب تراثية وإلكترونية لطلاب العلم'],
h1s:['Ebook, kitab terjemahan, dan kitab Arab asli. Pesan dari rumah, sampai ke pintu atau pesantren Anda.','كتب إلكترونية ومترجمة وعربية أصلية. اطلب من بيتك ويصلك إلى الباب أو المعهد.'],
cta:['Lihat katalog','تصفح الكتالوج'],wal:['Chat Admin WhatsApp','تواصل عبر واتساب'],
all:['Semua','الكل'],c_akidah:['Akidah','العقيدة'],c_fikih:['Fikih','الفقه'],c_hadits:['Hadist','الحديث'],c_tafsir:['Tafsir','التفسير'],c_bahasa:['Bahasa','اللغة'],c_sirah:['Sirah','السيرة'],
ty_e:['Ebook','كتب إلكترونية'],ty_t:['Kitab Terjemahan','كتب مترجمة'],ty_a:['Kitab Arab','كتب عربية'],
td_e:['PDF · kirim digital','PDF · إرسال رقمي'],td_t:['Cetak · bahasa Indonesia','مطبوعة · بالإندونيسية'],td_a:['Cetak · teks Arab asli','مطبوعة · بالنص العربي'],
ph:['Pilih jenis buku di atas (Ebook, Kitab Terjemahan, atau Kitab Arab) untuk melihat daftar buku.','اختر نوع الكتب أعلاه (إلكترونية أو مترجمة أو عربية) لعرض القائمة.'],none:['Belum ada buku untuk pilihan ini.','لا توجد كتب لهذا الاختيار.'],
cnt:['{n} judul','{n} عنوانًا'],showing:['Menampilkan {a}–{b} dari {n} buku','عرض {a}–{b} من {n} كتابًا'],

add:['+ Keranjang','+ أضف إلى السلة'],added:['✓ Ditambahkan','✓ تمت الإضافة'],cart:['Keranjang','سلة التسوق'],
empty:['Keranjang masih kosong','سلة التسوق فارغة'],keep:['Mulai belanja','ابدأ التسوق'],subtotal:['Subtotal','المجموع الفرعي'],checkout:['Checkout','إتمام الشراء'],
addr:['Alamat Pengiriman','عنوان الشحن'],contact:['Data Penerima','بيانات المستلم'],name:['Nama penerima','اسم المستلم'],phone:['No. HP / WhatsApp','رقم الجوال / واتساب'],email:['Email (untuk kirim ebook)','البريد الإلكتروني (لإرسال الكتب)'],
prov:['Provinsi','المحافظة'],city:['Kota / Kabupaten','المدينة / المنطقة'],dist:['Kecamatan','الناحية'],zip:['Kode pos','الرمز البريدي'],
street:['Alamat lengkap (jalan, nomor, RT/RW)','العنوان التفصيلي (الشارع، الرقم، RT/RW)'],note:['Catatan untuk penjual (opsional)','ملاحظة للبائع (اختياري)'],
home:['Rumah','البيت'],office:['Kantor','العمل'],pes:['Pesantren','المعهد'],items:['Produk dipesan','المنتجات المطلوبة'],
dig:['Ebook dikirim digital, tanpa ongkir.','الكتب الإلكترونية تُرسل رقميًا بلا رسوم شحن.'],
pay:['Metode Pembayaran','طريقة الدفع'],cod:['Bayar di Tempat (COD)','الدفع عند الاستلام (COD)'],voucher:['Kode Voucher','رمز القسيمة'],apply:['Pakai','تطبيق'],
vok:['Voucher dipakai: diskon {p}%','تم تطبيق القسيمة: خصم {p}%'],vbad:['Kode tidak valid','الرمز غير صحيح'],sum:['Rincian Pembayaran','تفاصيل الدفع'],
vd:['Diskon voucher','خصم القسيمة'],total:['Total','الإجمالي'],order:['Pesan via WhatsApp','اطلب عبر واتساب'],
dt:['Pesanan siap dikonfirmasi!','طلبك جاهز للتأكيد!'],ds:['Rincian pesanan sudah disiapkan. Lanjutkan ke WhatsApp admin agar ongkos kirim dihitung dan pembayaran dikonfirmasi. Jazakumullahu khairan.','تم تجهيز تفاصيل طلبك. تابع إلى واتساب المشرف لحساب رسوم الشحن وتأكيد الدفع. جزاكم الله خيرًا.'],wago:['Lanjutkan ke WhatsApp','تابع إلى واتساب'],wahint:['Belum termasuk ongkir. Admin akan menghitung dan mengonfirmasi ongkir lewat WhatsApp sebelum Anda membayar.','لا تشمل رسوم الشحن. سيحسبها المشرف ويؤكدها عبر واتساب قبل الدفع.'],totx:['Total (belum termasuk ongkir)','الإجمالي (بدون رسوم الشحن)'],
no:['Nomor pesanan','رقم الطلب'],back:['Kembali ke beranda','العودة إلى الرئيسية'],
fh:['Hubungi kami atau kunjungi toko offline Husein Store.','تواصلوا معنا أو زوروا متجرنا Husein Store.'],map:['Lokasi Toko Offline','موقع المتجر']
};
