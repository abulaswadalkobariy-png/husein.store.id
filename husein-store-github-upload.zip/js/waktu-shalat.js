/* ==========================================================
   BAGIAN 5 — WAKTU SHALAT (file: js/waktu-shalat.js)
   Kota waktu shalat dan rumus perhitungannya (metode Kemenag). Tambah kota: salin satu baris di CITIES.
   ========================================================== */
const fx=(a,b)=>a-b*Math.floor(a/b);
const PN=[['Subuh','Terbit','Dzuhur','Ashar','Maghrib','Isya'],['الفجر','الشروق','الظهر','العصر','المغرب','العشاء']];
const CITIES=[['Surabaya','سورابايا',-7.25,112.75,7],['Jakarta','جاكرتا',-6.21,106.85,7],['Bandung','باندونغ',-6.92,107.61,7],['Semarang','سمارانغ',-6.97,110.42,7],['Yogyakarta','يوغياكرتا',-7.8,110.36,7],['Malang','مالانغ',-7.98,112.63,7],['Medan','ميدان',3.59,98.67,7],['Makassar','ماكاسار',-5.15,119.43,8],['Denpasar','دنباسار',-8.65,115.22,8]];
/* Waktu shalat (metode Kemenag: Subuh 20°, Isya 18°, Ashar standar) dihitung langsung di browser */
function prayer(now,la,lo,tz){const R=Math.PI/180,L=new Date(now.getTime()+tz*36e5);
let Y=L.getUTCFullYear(),M=L.getUTCMonth()+1;const Dd=L.getUTCDate();if(M<3){Y--;M+=12}
const A=Math.floor(Y/100),jd=Math.floor(365.25*(Y+4716))+Math.floor(30.6001*(M+1))+Dd+2-A+Math.floor(A/4)-1524.5-lo/360;
const sun=j=>{const d=j-2451545,g=fx(357.529+.98560028*d,360),q=fx(280.459+.98564736*d,360),l=fx(q+1.915*Math.sin(g*R)+.02*Math.sin(2*g*R),360),e=23.439-3.6e-7*d,ra=fx(Math.atan2(Math.cos(e*R)*Math.sin(l*R),Math.cos(l*R))/R/15,24);return[Math.asin(Math.sin(e*R)*Math.sin(l*R))/R,q/15-ra]};
const mid=h=>fx(12-sun(jd+h)[1],24);
const ang=(a,h,c)=>{const dc=sun(jd+h)[0],v=(-Math.sin(a*R)-Math.sin(dc*R)*Math.sin(la*R))/(Math.cos(dc*R)*Math.cos(la*R));return mid(h)+(c?-1:1)*Math.acos(Math.max(-1,Math.min(1,v)))/R/15};
const asr=h=>ang(-Math.atan(1/(1+Math.tan(Math.abs(la-sun(jd+h)[0])*R)))/R,h);
const f=h=>[ang(20,h[0]/24,1),ang(.833,h[1]/24,1),mid(h[2]/24),asr(h[3]/24),ang(.833,h[4]/24),ang(18,h[5]/24)];
let r=f([5,6,12,13,18,18]);r=f(r);return r.map((x,i)=>x+tz-lo/15+[2,-2,2,2,2,2][i]/60)}
const hm=h=>{const m=Math.round(fx(h,24)*60);return String(Math.floor(m/60)%24).padStart(2,'0')+':'+String(m%60).padStart(2,'0')};
