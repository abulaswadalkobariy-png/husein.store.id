/* ==========================================================
   BAGIAN 7 — MESIN TOKO (file: js/app.js)
   Logika & tampilan. Tidak perlu diubah untuk menambah buku/harga/kontak.
   ========================================================== */
const JN={ebook:'e',terjemahan:'t',arab:'a'};
const P=BUKU.filter(b=>b.aktif!==false).map(b=>{const d=b.diskon||0;return{i:b.id,y:JN[b.jenis],c:b.kategori,a:b.arab,n:b.nama,p:b.harga,d,u:b.judul||0,g:b.gambar||'',e:Math.round(b.harga*(100-d)/100/500)*500}});
let lang='id',cart={},st={v:0,f:null,type:null,cat:null,disc:0,menu:0,city:0,qty:{},pg:0,sd:1},order=null,cur='',sub=0;
const $=s=>document.querySelector(s);
const t=k=>D[k][lang==='ar'?1:0];
const vok=()=>t('vok').replace('{p}',VOUCHER.persen);
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const price=n=>`<bdi>${n<0?'−':''}Rp${Math.abs(n).toLocaleString('id-ID')}</bdi>`;
const nm=p=>lang==='ar'?p.a:p.n;
const items=()=>Object.keys(cart).map(i=>({...P.find(p=>p.i===i),q:cart[i]}));
const cnt=()=>Object.values(cart).reduce((a,b)=>a+b,0);
const phys=x=>x.y!=='e';
function calc(){const s=items().reduce((a,x)=>a+x.e*x.q,0),vd=st.v?Math.round(s*VOUCHER.persen/100):0;return{sub:s,vd,tot:s-vd}}

const pts=()=>{const c=CITIES[st.city],now=new Date(),T=prayer(now,c[2],c[3],c[4]),lh=(now.getUTCHours()+now.getUTCMinutes()/60+c[4])%24;
let nx=T.findIndex((x,i)=>i!=1&&x>lh);if(nx<0)nx=0;return T.map((x,i)=>`<div class="pt${i==nx?' nx':''}"><small>${PN[lang=='ar'?1:0][i]}</small><b>${hm(x)}</b></div>`).join('')};
const info=()=>{const c=CITIES[st.city],now=new Date(),zn=c[4]==7?'Asia/Jakarta':'Asia/Makassar',ar=lang=='ar';let g='',h='';
try{g=new Intl.DateTimeFormat(ar?'ar-u-ca-gregory-nu-latn':'id-ID',{weekday:'long',day:'numeric',month:'long',year:'numeric',timeZone:zn}).format(now);
h=new Intl.DateTimeFormat(ar?'ar-u-ca-islamic-umalqura-nu-latn':'id-u-ca-islamic-umalqura',{day:'numeric',month:'long',year:'numeric',timeZone:zn}).format(now)}catch(e){}
return `<div class="w"><div class="dts"><b>${g}</b><span>${h} · ${c[4]==7?'WIB':'WITA'}</span></div><select id="city" aria-label="${t('city')}">${CITIES.map((x,i)=>`<option value="${i}"${i==st.city?' selected':''}>${x[ar?1:0]}</option>`).join('')}</select><div class="pts" id="pts">${pts()}</div></div>`};

const cv=p=>`<div class="cv ${p.y}">${p.g?`<img src="${esc(p.g)}" alt="" loading="lazy">`:''}${p.d?`<u>−${p.d}%</u>`:''}${p.y=='e'?'<em>PDF</em>':''}<b>${p.a}</b><small>${t('ty_'+p.y)}</small></div>`;
const card=p=>`<article class="card">${cv(p)}<div class="bd"><span class="tag">${t('ty_'+p.y)}</span><h3>${nm(p)}</h3><p>${t('c_'+p.c)}${p.u?' · '+t('cnt').replace('{n}',p.u):''}</p><div class="pr"><div class="pp"><b>${price(p.e)}</b>${p.d?`<s>${price(p.p)}</s>`:''}</div><div class="q"><button data-cq="${p.i},-1" aria-label="−">−</button><b id="q-${p.i}">${st.qty[p.i]||1}</b><button data-cq="${p.i},1" aria-label="+">+</button></div><button class="btn" data-a="${p.i}">${t('add')}</button></div></div></article>`;
const pager=(pages,n,tot)=>pages<2?'':`<div class="pgr"><div class="mu">${t('showing').replace('{a}',st.pg*PER_SLIDE+1).replace('{b}',st.pg*PER_SLIDE+n).replace('{n}',tot)}</div><div class="pn"><button class="ar" data-pg="prev"${st.pg?'':' disabled'} aria-label="‹">‹</button>${Array.from({length:pages},(_,i)=>`<button class="${i==st.pg?'on':''}" data-pg="${i}">${i+1}</button>`).join('')}<button class="ar" data-pg="next"${st.pg<pages-1?'':' disabled'} aria-label="›">›</button></div></div>`;
const catalog=()=>{const list=P.filter(p=>(!st.type||p.y===st.type)&&(!st.cat||p.c===st.cat)&&(!st.disc||p.d>0)),any=st.type||st.cat||st.disc,pages=Math.max(1,Math.ceil(list.length/PER_SLIDE));st.pg=Math.min(st.pg,pages-1);const view=list.slice(st.pg*PER_SLIDE,st.pg*PER_SLIDE+PER_SLIDE);
return `<div class="tiles">${['e','t','a'].map(y=>`<button class="tl${st.type==y?' on':''}" data-ty="${y}"><i>${{e:'PDF',t:'ID',a:'ع'}[y]}</i><b>${t('ty_'+y)}</b><span>${t('td_'+y)}</span></button>`).join('')}</div>
<div class="fc"><button class="${st.cat?'':'on'}" data-c="">${t('all')}</button>${CATS.map(c=>`<button class="${st.cat==c?'on':''}" data-c="${c}">${t('c_'+c)}</button>`).join('')}<button class="${st.disc?'on':''}" data-dc>${t('n_disc')}</button></div>
${!any?`<div class="ph">${t('ph')}</div>`:list.length?`<div class="grid" style="--sx:${st.sd*(lang=='ar'?-1:1)*28}px">${view.map(card).join('')}</div>${pager(pages,view.length,list.length)}`:`<div class="ph">${t('none')}</div>`}`};
const fld=(n,k,o='')=>`<div${/f/.test(o)?' class="full"':''}><label class="fl">${t(k)}</label>${/t/.test(o)?`<textarea name="${n}" rows="3" ${/r/.test(o)?'required':''}></textarea>`:`<input name="${n}" ${/r/.test(o)?'required':''} ${/e/.test(o)?'type="email"':/p/.test(o)?'type="tel" pattern="[0-9+ ]{9,16}"':/z/.test(o)?'inputmode="numeric" pattern="[0-9]{5}"':''}>`}</div>`;
const hdr=()=>`<header class="hd"><div class="w hdi"><a class="logo" href="#home"><i>ح</i>${t('brand')}</a><div class="tools"><div class="lg"><button data-l="id" class="${lang=='id'?'on':''}">ID</button><button data-l="ar" class="${lang=='ar'?'on':''}">عربي</button></div><a class="cb" href="#cart" aria-label="${t('cart')}"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M3 4h2l2.4 11h10.2L20 7H6"/><circle cx="9" cy="20" r="1.5"/><circle cx="17" cy="20" r="1.5"/></svg><span class="bdg" id="bd">${cnt()||''}</span></a></div></div>
<div class="w nv"><button data-nav="home">${t('n_home')}</button><button data-nav="katalog">${t('n_cat')}</button><button data-nav="disc">${t('n_disc')}</button><button data-nav="kat" class="${st.menu?'on':''}">${t('n_kat')} ▾</button></div>${st.menu?`<div class="w cm">${CATS.map(c=>`<button data-hc="${c}">${t('c_'+c)}</button>`).join('')}</div>`:''}</header>`;
const wurl=`https://wa.me/${WA}?text=${encodeURIComponent(MSG)}`;
const wa=up=>`<a class="wa${up?' up':''}" href="${wurl}" target="_blank" rel="noopener" aria-label="WhatsApp"><svg viewBox="0 0 24 24" width="30" height="30" fill="#fff"><path d="${WAP}"/></svg></a>`;
const ftr=()=>`<footer class="ft"><div class="w"><div class="fb"><i>ح</i>${t('brand')}</div><p>${t('fh')}</p><div class="sc">${[['mail','Email',CT.mail],['ig','Instagram',CT.ig],['tg','Telegram',CT.tg],['map',t('map'),CT.map]].map(([k,l,u])=>`<a href="${u}" target="_blank" rel="noopener"><span>${ic(IC[k])}</span>${l}</a>`).join('')}</div><div class="cp">© 2026 ${t('brand')}</div></div></footer>`;

const V={
home:()=>`<div class="info" id="info">${info()}</div><section class="hero"><div class="bn" role="img" aria-label="Husein Store"></div><div class="w"><h1>${t('h1')}</h1><p>${t('h1s')}</p><div class="cta"><button class="gold" data-nav="katalog">${t('cta')}</button><a class="wl" href="${wurl}" target="_blank" rel="noopener"><svg viewBox="0 0 24 24" width="20" height="20"><path d="${WAP}"/></svg>${t('wal')}</a></div></div></section>
<div class="w" id="katalog"><div id="cat">${catalog()}</div></div>`,
cart:()=>{const it=items();if(!it.length)return `<div class="w pg tc"><h2>${t('empty')}</h2><a class="btn" href="#home">${t('keep')}</a></div>`;
return `<div class="w pg"><h2>${t('cart')}</h2><div class="box">${it.map(x=>`<div class="row">${cv(x)}<div class="in"><b>${nm(x)}</b><div>${price(x.e)}</div></div><div class="q"><button data-q="${x.i},-1">−</button><b>${x.q}</b><button data-q="${x.i},1">+</button></div></div>`).join('')}</div></div>
<div class="bar"><div class="w"><div><small>${t('subtotal')}</small><div class="tot">${price(calc().sub)}</div></div><a class="btn" href="#checkout">${t('checkout')}</a></div></div>`},
checkout:()=>{const it=items(),K=it.some(phys),E=it.some(x=>!phys(x));
return `<form id="co" class="w pg"><div class="box"><h3>${t(K?'addr':'contact')}</h3>${K?`<div class="chips">${['home','office','pes'].map((x,i)=>`<label><input type="radio" name="lb" value="${x}"${i?'':' checked'}>${t(x)}</label>`).join('')}</div>`:''}
<div class="f">${fld('name','name','r')}${fld('phone','phone','rp')}${E?fld('email','email','rfe'):''}${K?`<div><label class="fl">${t('prov')}</label><select name="prov" required><option value=""></option>${PV.map(x=>`<option>${x}</option>`).join('')}</select></div>${fld('city','city','r')}${fld('dist','dist','r')}${fld('zip','zip','rz')}${fld('street','street','rft')}${fld('note','note','ft')}`:''}</div></div>
<div class="box"><h3>${t('items')}</h3>${it.map(x=>`<div class="row">${cv(x)}<div class="in"><b>${nm(x)}</b><div class="mu">×${x.q}</div></div><b>${price(x.e*x.q)}</b></div>`).join('')}</div>

${E?`<div class="box mu">${t('dig')}</div>`:''}
<div class="box"><h3>${t('pay')}</h3>${PY.map((n,i)=>n==='COD'&&E?'':`<label class="opt"><input type="radio" name="py" value="${i}"${i?'':' checked'}><div class="g"><b>${n==='COD'?t('cod'):n}</b></div></label>`).join('')}</div>
<div class="box"><h3>${t('voucher')}</h3><div class="vr"><input id="vc" placeholder="${VOUCHER.kode}" value="${st.v?VOUCHER.kode:''}"><button type="button" class="btn" data-v>${t('apply')}</button></div><div class="mu" id="vm">${st.v?vok():''}</div></div>
<div class="box sm" id="sm"></div>
<div class="bar"><div class="w"><div><small>${t('total')}</small><div class="tot" id="tt"></div></div><button class="btn" type="submit">${t('order')}</button></div></div></form>`},
done:()=>`<div class="w pg"><div class="box dn"><div class="chk">✓</div><h2>${t('dt')}</h2><p>${t('ds')}</p><div class="sm"><div><span>${t('no')}</span><b>${order.no}</b></div><div><span>${t('total')}</span><b>${price(order.total)}</b></div><div><span>${t('pay')}</span><b>${order.pay}</b></div></div><p class="mu">${order.dest}</p><a class="wb" href="${order.url}" target="_blank" rel="noopener"><svg viewBox="0 0 24 24" width="22" height="22" fill="#fff"><path d="${WAP}"/></svg>${t('wago')}</a><a class="btn" href="#home">${t('back')}</a></div></div>`
};
function updateSum(){const c=calc(),K=items().some(phys);
$('#sm').innerHTML=`<h3>${t('sum')}</h3><div><span>${t('subtotal')}</span><span>${price(c.sub)}</span></div>${c.vd?`<div><span>${t('vd')}</span><span>${price(-c.vd)}</span></div>`:''}<div class="t"><span>${t(K?'totx':'total')}</span><span>${price(c.tot)}</span></div>${K?`<div class="mu">${t('wahint')}</div>`:''}`;
$('#tt').innerHTML=price(c.tot)}
function render(){
const fm=$('#co');if(fm&&!sub)st.f=Object.fromEntries(new FormData(fm));sub=0;
let v=location.hash.slice(1);if(!['home','cart','checkout','done'].includes(v))v='home';
if(v==='checkout'&&!cnt())v='cart';if(v==='done'&&!order)v='home';
const y=scrollY,same=v===cur;cur=v;
document.documentElement.lang=lang;document.documentElement.dir=lang==='ar'?'rtl':'ltr';
$('#app').innerHTML=hdr()+`<main>${V[v]()}</main>`+ftr()+wa(v=='cart'||v=='checkout');
if(v==='checkout'){updateSum();const f=$('#co');for(const k in st.f)if(f.elements[k])f.elements[k].value=st.f[k]}
scrollTo(0,same?y:0)}
const renderCat=()=>{$('#cat').innerHTML=catalog()};
const show=id=>{const s=()=>document.getElementById(id)?.scrollIntoView({behavior:'smooth'});
if(cur==='home'){render();setTimeout(s,40)}else{location.hash='home';setTimeout(s,120)}};
document.addEventListener('click',e=>{const b=e.target.closest('[data-a],[data-q],[data-cq],[data-l],[data-nav],[data-ty],[data-c],[data-dc],[data-hc],[data-v],[data-pg]');if(!b)return;const d=b.dataset;
if(d.l){lang=d.l;return render()}
if(d.nav){if(d.nav==='kat'){st.menu=!st.menu;return render()}st.menu=0;
if(d.nav==='home'){if(cur==='home'){render();return scrollTo({top:0,behavior:'smooth'})}return location.hash='home'}
if(d.nav==='disc'){st.disc=1;st.type=st.cat=null;st.pg=0}return show('katalog')}
if(d.hc!==undefined){st.cat=d.hc;st.pg=0;st.disc=0;st.menu=0;return show('katalog')}
if(d.ty){st.pg=0;st.type=st.type===d.ty?null:d.ty;return renderCat()}
if(d.c!==undefined){st.pg=0;st.cat=d.c||null;return renderCat()}
if(d.dc!==undefined){st.pg=0;st.disc=st.disc?0:1;return renderCat()}
if(d.pg!==undefined){const i=d.pg;st.sd=i==='prev'||(i!=='next'&&+i<st.pg)?-1:1;st.pg=i==='prev'?st.pg-1:i==='next'?st.pg+1:+i;renderCat();return $('.fc').scrollIntoView({behavior:'smooth'})}
if(d.cq){const[i,n]=d.cq.split(',');st.qty[i]=Math.max(1,Math.min(99,(st.qty[i]||1)+ +n));$('#q-'+i).textContent=st.qty[i];return}
if(d.a){const i=d.a;cart[i]=(cart[i]||0)+(st.qty[i]||1);st.qty[i]=1;$('#q-'+i).textContent=1;$('#bd').textContent=cnt();
b.textContent=t('added');b.classList.add('ok');return setTimeout(()=>{b.textContent=t('add');b.classList.remove('ok')},1200)}
if(d.q){const[i,n]=d.q.split(',');cart[i]=(cart[i]||0)+ +n;if(cart[i]<1)delete cart[i];return render()}
if(d.v!==undefined){st.v=$('#vc').value.trim().toUpperCase()===VOUCHER.kode.toUpperCase()?1:0;$('#vm').textContent=st.v?vok():t('vbad');updateSum()}});
document.addEventListener('change',e=>{if(e.target.id==='city'){st.city=+e.target.value;$('#info').innerHTML=info()}});
const rp=n=>'Rp'+n.toLocaleString('id-ID');
/* Pesan ke WhatsApp admin: rincian pesanan, ongkir (estimasi) & data penerima */
document.addEventListener('submit',e=>{e.preventDefault();const fd=new FormData(e.target),it=items(),K=it.some(phys),c=calc(),py=+fd.get('py'),cod=PY[py]==='COD',no='HS'+Date.now().toString().slice(-8);
const M=['Assalamualaikum Warahmatullahi Wabarakatuh, saya ingin memesan di '+D.brand[0]+':','','*No. Pesanan:* '+no,'','*Pesanan:*',
...it.map((x,i)=>`${i+1}. ${x.n} [${D['ty_'+x.y][0]}] - ${x.q} x ${rp(x.e)} = ${rp(x.e*x.q)}`),'','Subtotal: '+rp(c.sub),
c.vd?`Voucher ${VOUCHER.kode}: -${rp(c.vd)}`:null,
'*Total'+(K?' (belum termasuk ongkir)':'')+': '+rp(c.tot)+'*','Pembayaran: '+(cod?D.cod[0]:PY[py]),'','*Data penerima:*','Nama: '+fd.get('name'),'HP/WA: '+fd.get('phone'),
fd.get('email')?'Email: '+fd.get('email'):null,K?'Alamat: '+[fd.get('street'),'Kec. '+fd.get('dist'),fd.get('city'),fd.get('prov'),fd.get('zip')].join(', '):null,
fd.get('note')?'Catatan: '+fd.get('note'):null,'',K?'Mohon dihitungkan ongkos kirimnya, lalu info total akhir dan cara pembayarannya. Jazakumullahu khairan.':'Mohon info cara pembayarannya. Jazakumullahu khairan.'];
const url=`https://wa.me/${WA}?text=${encodeURIComponent(M.filter(x=>x!==null).join('\n'))}`;
order={no,total:c.tot,pay:cod?t('cod'):PY[py],url,
dest:esc(fd.get('name'))+' · '+esc(fd.get('phone'))+'\n'+esc(K?[fd.get('street'),fd.get('dist'),fd.get('city'),fd.get('prov')].join(', ')+' '+fd.get('zip'):fd.get('email'))};
cart={};st.v=0;st.f=null;sub=1;location.hash='done';window.open(url,'_blank','noopener')});
let tx=0,ty=0;document.addEventListener('touchstart',e=>{tx=e.changedTouches[0].clientX;ty=e.changedTouches[0].clientY},{passive:true});
document.addEventListener('touchend',e=>{if(!e.target.closest('.grid'))return;const dx=e.changedTouches[0].clientX-tx;if(Math.abs(dx)<60||Math.abs(e.changedTouches[0].clientY-ty)>Math.abs(dx))return;
const b=$(`.pn [data-pg="${(dx<0)!==(lang=='ar')?'next':'prev'}"]`);if(b&&!b.disabled)b.click()});
document.addEventListener('error',e=>{if(e.target.tagName==='IMG')e.target.remove()},true);  // foto gagal dimuat -> pakai sampul otomatis
setInterval(()=>{const e=$('#pts');if(e)e.innerHTML=pts()},60000);
addEventListener('hashchange',render);
render();
