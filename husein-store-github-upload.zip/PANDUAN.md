# Panduan Mengelola Husein Store

Website ini dibuat **per bagian** supaya mudah diedit. Buka file `.js` dengan editor teks
(Notepad, Notepad++, atau VS Code — **jangan pakai Microsoft Word**).

## 1. Peta file — mau ubah apa, buka file mana

| Mau mengubah...                                   | Buka file             |
|---------------------------------------------------|-----------------------|
| **Daftar kitab/ebook, harga, diskon, foto sampul** | `js/buku.js`          |
| Nomor WhatsApp, email, IG, Telegram, Maps, voucher | `js/config.js`        |
| Tulisan/teks Indonesia & Arab                      | `js/bahasa.js`        |
| Kota waktu shalat                                  | `js/waktu-shalat.js`  |
| Warna, tampilan & **font Arab**                    | `css/style.css`       |
| Foto banner & sampul buku                          | folder `gambar/`      |
| Mesin toko (keranjang, checkout)                   | `js/app.js` *(jangan diubah)* |

## 2. Membuka & memasang di internet

- **Coba di komputer:** klik dua kali `index.html`.
- **Online:** upload **seluruh folder** `husein-store` ke hosting (hosting biasa, atau layanan hosting
  statis gratis). Pastikan struktur folder tetap sama.
- Setiap selesai mengedit file, simpan, lalu upload ulang file yang berubah dan refresh halaman (Ctrl+F5).

## 3. Menambah kitab / ebook baru  (`js/buku.js`)

Satu baris `{ ... }` = satu buku. Cara menambah:

1. Buka `js/buku.js`.
2. **Salin satu baris buku yang sejenis**, tempel tepat di bawahnya.
3. Ubah isinya. Contoh kitab Arab baru:

```js
{id:'a9', jenis:'arab', kategori:'fikih', arab:'الأربعين النووية', nama:'Arbain Nawawi', harga:40000, diskon:0, gambar:''},
```

| Isian      | Arti                                                                 |
|------------|----------------------------------------------------------------------|
| `id`       | Kode **unik** (tidak boleh sama dengan buku lain), mis. `a9`, `t9`, `e7` |
| `jenis`    | `'ebook'`, `'terjemahan'`, atau `'arab'` (tulis persis, huruf kecil)  |
| `kategori` | `akidah`, `fikih`, `hadits`, `tafsir`, `bahasa`, `sirah`              |
| `arab`     | Judul Arab (tampil di sampul)                                         |
| `nama`     | Nama Indonesia (tampil sebagai judul)                                 |
| `harga`    | Harga normal, angka saja tanpa titik: `95000`                         |
| `diskon`   | Persen diskon. `0` = tidak diskon. `15` = diskon 15% (harga coret otomatis) |
| `judul`    | Khusus ebook: jumlah judul dalam paket, mis. `judul:70`               |
| `gambar`   | Foto sampul (lihat bagian 5). Kosongkan `''` = sampul otomatis        |

**Aturan penting:** setiap nilai teks diapit tanda petik `'...'`, antar isian dipisah koma,
dan setiap baris buku **diakhiri koma** `},`.

Slide: setiap 5 buku otomatis pindah ke slide berikutnya (1, 2, 3, ...). Tidak perlu diatur.

## 4. Mengurangi / mengubah buku

- **Menghapus:** hapus satu baris buku itu seluruhnya.
- **Menyembunyikan sementara** (mis. stok habis): tambahkan `aktif:false,` di dalam baris,
  `{id:'a9', aktif:false, jenis:'arab', ...},` — hapus tulisan itu kalau stok ada lagi.
- **Ubah harga / diskon:** ganti angka `harga` atau `diskon`.

## 5. Menambah foto sampul buku

1. Siapkan foto sampul **tegak (rasio 3:4), contoh 600 × 800 px**, format JPG atau WebP,
   usahakan **di bawah 150 KB** (kecilkan dulu dengan aplikasi kompres gambar).
2. Beri nama file **huruf kecil, tanpa spasi**: `fathul-qarib.jpg`.
3. Taruh file di folder `gambar/`.
4. Di `js/buku.js`, isi pada baris buku itu:

```js
gambar:'gambar/fathul-qarib.jpg'
```

5. Simpan, upload folder `gambar/` dan `buku.js`, lalu refresh.

Jika foto tidak muncul: cek ejaan nama file (huruf besar/kecil berpengaruh) dan pastikan file ada di
folder `gambar/`. Jika foto gagal dimuat, toko otomatis memakai sampul bawaan.

**Mengganti banner beranda:** timpa file `gambar/banner.webp` dengan gambar baru (lebar ± 1280 px).

## 6. Menambah kategori baru (3 langkah)

Contoh menambah kategori **Tasawuf**:
1. `js/buku.js` → pada baris `CATS`, tambahkan `'tasawuf'`:
   `const CATS=['akidah','fikih','hadits','tafsir','bahasa','sirah','tasawuf'];`
2. `js/bahasa.js` → tambahkan tulisannya setelah `c_sirah:[...]`:
   `c_tasawuf:['Tasawuf','التصوف'],`
3. Pakai di buku: `kategori:'tasawuf'`.

## 7. Mengganti nomor WhatsApp, kontak, voucher (`js/config.js`)

- `WA` → nomor admin, awali `62` tanpa `0` (0897xxxx → `62897xxxx`).
- `CT` → email, Instagram, Telegram, dan link Google Maps toko. **Isi sekarang masih contoh, mohon diganti.**
- `VOUCHER` → kode & persen diskon. `PER_SLIDE` → jumlah buku per slide.

## 8. Ongkir

Website **tidak menghitung ongkir**. Ongkir dihitung admin berdasarkan alamat pembeli dan dikonfirmasi
lewat WhatsApp sebelum pembayaran. Total di website = total belanja buku saja.

## 9. Alur pemesanan

1. Pembeli pilih buku → keranjang → checkout, isi alamat lengkap.
2. Klik **Pesan via WhatsApp** → WhatsApp admin terbuka berisi rincian pesanan, total belanja,
   dan alamat.
3. Admin menghitung ongkir sesuai alamat, lalu membalas dengan total akhir dan info pembayaran.

Data pesanan **tidak tersimpan di server**; semuanya lewat chat WhatsApp.

## 10. Mengganti font Arab

Font Arab yang dipakai: **Noto Kufi Arabic**. Untuk mengganti, ubah **dua tempat**:
1. `css/style.css`, baris paling atas: `--fa:'Noto Kufi Arabic';` → tulis nama font lain, mis. `--fa:'Tajawal';`
2. `index.html`, pada tulisan `family=Noto+Kufi+Arabic:wght@400;600;700` → ganti dengan nama font tersebut
   (nama dan ukuran huruf mengikuti daftar Google Fonts, mis. `family=Tajawal:wght@400;700`).

## 11. Jika ada masalah

- **Halaman kosong / buku tidak muncul** → biasanya ada koma atau tanda petik yang kurang di `buku.js`.
  Tekan **F12 → Console**, lihat baris yang disebut error.
- **Buku tidak tampil di jenisnya** → cek ejaan `jenis` (`ebook`, `terjemahan`, `arab`) dan `kategori`.
- **Buku hilang satu** → `id` kembar, atau ada `aktif:false`.
- Lakukan perubahan sedikit-sedikit dan **simpan salinan** folder sebelum mengedit.

## 12. Memasang website agar bisa dibuka semua orang (HP & laptop)

Website ini hanya berisi file biasa (HTML/CSS/JS), jadi bisa dipasang di layanan hosting apa pun.

1. Ekstrak `husein-store.zip` — pastikan `index.html` berada di folder paling atas yang diunggah.
2. Pilih tempat hosting: hosting statis (mis. Netlify, Cloudflare Pages, GitHub Pages) atau hosting biasa
   (cPanel: unggah isi folder ke `public_html`). Cek syarat & biaya terbaru di layanan masing-masing.
3. Unggah seluruh isi folder (`index.html`, `css`, `js`, `gambar`). Anda akan mendapat alamat web.
4. **Domain sendiri** (mis. huseinstore.com / .id): beli di penyedia domain, lalu sambungkan
   ke hosting lewat menu *custom domain* / pengaturan DNS hosting.
5. Buka alamat webnya di HP dan laptop, coba pesan satu kali sampai WhatsApp terbuka.
6. Pasang link di bio Instagram, status/profil WhatsApp Business, dan profil Google Maps toko.

Setelah mengedit buku/harga: unggah ulang file yang berubah, lalu refresh (Ctrl+F5).
